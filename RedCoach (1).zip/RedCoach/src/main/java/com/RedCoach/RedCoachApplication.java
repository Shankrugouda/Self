package com.RedCoach;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedCoachApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedCoachApplication.class, args);
	}

}
