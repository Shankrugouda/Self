package com.RedCoach;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedCoachApplicationTests {

	@Test
	void contextLoads() {
	}

}
